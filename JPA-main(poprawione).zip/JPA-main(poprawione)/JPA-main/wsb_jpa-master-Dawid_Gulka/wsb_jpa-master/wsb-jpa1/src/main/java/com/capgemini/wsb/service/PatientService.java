package com.capgemini.wsb.service;

import com.capgemini.wsb.dto.PatientTO;
import com.capgemini.wsb.dto.VisitTO;

import java.util.List;

public interface PatientService {
    PatientTO findById(Long id);
    PatientTO save(PatientTO patientTO);
    void delete(Long id);
    List<VisitTO> findAllVisitsByPatientId(Long patientId);
}
