-- Insert addresses
INSERT INTO address (id, address_line1, address_line2, city, postal_code) VALUES (1, 'line1', 'line2', 'city1', '62-030');
INSERT INTO address (id, address_line1, address_line2, city, postal_code) VALUES (2, 'line1', 'line2', 'city2', '62-031');

-- Insert doctors
INSERT INTO doctor (id, first_name, last_name, telephone_number, email, doctor_number, specialization, address_id) VALUES (1, 'John', 'Doe', '123456789', 'john.doe@example.com', 'DOC123', 'SURGEON', 1);

-- Insert patients
INSERT INTO patient (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth, address_id, additional_field) VALUES (1, 'Jane', 'Smith', '987654321', 'jane.smith@example.com', 'PAT456', '1980-01-01', 2, 'Some Additional Info 1');
INSERT INTO patient (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth, address_id, additional_field) VALUES (2, 'Alice', 'Johnson', '987654322', 'alice.johnson@example.com', 'PAT457', '1985-02-02', 2, 'Some Additional Info 2');
INSERT INTO patient (id, first_name, last_name, telephone_number, email, patient_number, date_of_birth, address_id, additional_field) VALUES (3, 'Bob', 'Brown', '987654323', 'bob.brown@example.com', 'PAT458', '1990-03-03', 2, 'Some Additional Info 3');

-- Insert visits
INSERT INTO visit (id, description, time, doctor_id, patient_id) VALUES (1, 'Routine checkup', '2023-05-19 10:00:00', 1, 1);
INSERT INTO visit (id, description, time, doctor_id, patient_id) VALUES (2, 'Follow-up', '2023-05-20 11:00:00', 1, 1);
INSERT INTO visit (id, description, time, doctor_id, patient_id) VALUES (3, 'Initial consultation', '2023-05-21 12:00:00', 1, 2);
INSERT INTO visit (id, description, time, doctor_id, patient_id) VALUES (4, 'Emergency visit', '2023-05-22 13:00:00', 1, 3);
INSERT INTO visit (id, description, time, doctor_id, patient_id) VALUES (5, 'Routine checkup', '2023-05-23 14:00:00', 1, 1);
