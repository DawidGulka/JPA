package com.capgemini.wsb.persistence.dao;

import com.capgemini.wsb.persistence.entity.VisitEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class VisitRepositoryTest {

    @Autowired
    private VisitRepository visitRepository;

    @Test
    public void testFindAllByPatientId() {
        // given
        Long patientId = 1L;

        // when
        List<VisitEntity> visits = visitRepository.findAllByPatientId(patientId);

        // then
        assertThat(visits).isNotEmpty();
        assertThat(visits.get(0).getPatient().getId()).isEqualTo(patientId);
    }
}
