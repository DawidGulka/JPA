package com.capgemini.wsb.service;

import com.capgemini.wsb.dto.PatientTO;
import com.capgemini.wsb.dto.VisitTO;
import com.capgemini.wsb.persistence.dao.PatientRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class PatientServiceTest {

    @Autowired
    private PatientService patientService;

    @Autowired
    private PatientRepository patientRepository;

    @Transactional
    @Test
    public void testFindAllVisitsByPatientId() {
        // given
        Long patientId = 1L;

        // when
        List<VisitTO> visits = patientService.findAllVisitsByPatientId(patientId);

        // then
        assertThat(visits).isNotEmpty();
        assertThat(visits.get(0).getPatient().getId()).isEqualTo(patientId);
    }

    @Transactional
    @Test
    public void testShouldDeletePatientAndCascadeVisits() {
        // given
        Long patientId = 1L;
        Long initialDoctorCount = patientRepository.count();

        // when
        patientService.delete(patientId);

        // then
        assertThat(patientRepository.existsById(patientId)).isFalse();
        // Sprawdź, czy wizyty zostały usunięte (kaskadowo)
        // Sprawdź, czy doktorzy nie zostali usunięci
        assertThat(patientRepository.count()).isEqualTo(initialDoctorCount);
    }

    @Test
    public void testShouldFindPatientById() {
        // given
        Long patientId = 1L;

        // when
        PatientTO patientTO = patientService.findById(patientId);

        // then
        assertThat(patientTO).isNotNull();
        assertThat(patientTO.getId()).isEqualTo(patientId);
        assertThat(patientTO.getAdditionalField()).isEqualTo("Some Additional Info 1");
    }
}
