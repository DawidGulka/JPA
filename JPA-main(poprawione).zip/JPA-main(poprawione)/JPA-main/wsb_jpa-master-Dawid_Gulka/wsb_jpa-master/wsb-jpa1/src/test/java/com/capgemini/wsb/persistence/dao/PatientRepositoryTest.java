package com.capgemini.wsb.persistence.dao;

import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class PatientRepositoryTest {

    @Autowired
    private PatientRepository patientRepository;

    @Test
    public void testFindByLastName() {
        // given
        String lastName = "Smith";

        // when
        List<PatientEntity> patients = patientRepository.findByLastName(lastName);

        // then
        assertThat(patients).isNotEmpty();
        assertThat(patients.get(0).getLastName()).isEqualTo(lastName);
    }

    @Test
    public void testFindPatientsWithMoreThanXVisits() {
        // given
        Long visitCount = 2L;

        // when
        List<PatientEntity> patients = patientRepository.findPatientsWithMoreThanXVisits(visitCount);

        // then
        assertThat(patients).isNotEmpty();
        assertThat(patients.get(0).getVisits().size()).isGreaterThan(visitCount.intValue());
    }

    @Test
    public void testFindByAdditionalFieldContaining() {
        // given
        String additionalField = "Info 1";

        // when
        List<PatientEntity> patients = patientRepository.findByAdditionalFieldContaining(additionalField);

        // then
        assertThat(patients).isNotEmpty();
        assertThat(patients.get(0).getAdditionalField()).contains(additionalField);
    }
}
